# LeNhip — 5 giao diện cá nhân hóa

Bản mã nguồn giao diện web responsive v1.0.0, bàn giao để LeDB phát triển tiếp.
Giao diện responsive cho trình duyệt điện thoại và máy tính.
Không phải app native đã tích hợp HealthKit/Health Connect.

## Chạy

Không cần npm install, không gọi CDN.
Tại thư mục dự án, chạy một static server có sẵn, ví dụ:
python3 -m http.server 8080 --directory dist
Mở http://localhost:8080

Mở LeNhip_Preview.html trong trình duyệt để dùng thử ngay trên máy tính, không cần máy chủ. Để phát triển với mã nguồn trong dist/, dùng HTTP vì mã nguồn chia thành JavaScript modules.
Một số trình duyệt di động hạn chế mở source tải về. Chạy từ máy phát triển hoặc host static.

## Kiểm tra

node --check dist/app.js
node --check dist/model.js
npm test

## 5 phương án

- PA01 Quỹ đạo — trắng, Cyan, vàng, orb LeLe và bố cục tổng quan.
- PA02 Không gian đêm — xanh đêm, Cyan, tím.
- PA03 Nhịp an — trắng ngà, xanh dịu, giao diện ấm.
- PA04 Dòng thời gian — hành trình theo thời gian.
- PA05 Titanium — xám kim loại, Cyan, lối vào từng không gian.

## Cá nhân hóa

Mở nút điều chỉnh góc trên. Chọn theme, tên, cỡ chữ, màu nhấn, giảm chuyển động,
bố cục gọn, widget hiển thị. Lưu để áp dụng cho hồ sơ đang chọn.
Nút avatar quản lý tối đa 8 hồ sơ demo. Từng hồ sơ có theme, lịch demo và đèn riêng.
Có xuất/nhập JSON chỉ chứa tùy chọn giao diện, không xuất lịch hoặc hội thoại.
Lưu trong localStorage theo trình duyệt/origin. Nếu không lưu được, app thông báo.
Đây là tách dữ liệu giao diện trong demo, chưa là cách ly tài khoản hay xác thực bảo mật.

## Hành vi có thể thử

- Bốn trang Hôm nay, Sức khỏe, Công việc, Ngôi nhà.
- Lịch: tạo khung giờ, xem lại, xác nhận và phát hiện khung giờ trùng trong demo.
- Đèn: đổi trạng thái minh họa. Robot: kịch bản mô phỏng.
- LeLe: hội thoại hướng dẫn theo kịch bản, chưa gọi API AI.
- Hỗ trợ focus, nhãn trợ năng, bàn phím, reduced-motion, mobile safe area.

## Điểm tích hợp cho LeDB

dist/model.js chứa theme tokens và chuẩn hóa cấu hình.
dist/styles.css định nghĩa 5 palette và các bố cục.
dist/app.js hiện dùng localStorage và dữ liệu mẫu; thay bằng adapter qua API đã đặc tả.
Khi nối hệ thống thật, dùng IAM và namespace người dùng ở máy chủ. Kiểm quyền server-side,
ràng buộc xác nhận/digest và xử lý UNKNOWN theo SRS V1.1.
Không đưa lệnh thiết bị thật vào handler demo hoặc coi localStorage là kho sức khỏe bảo mật.

Thiết kế 3D hiện thực bằng CSS và SVG nội bộ, không nhúng chữ trong ảnh.
Giao diện triển khai lấy hướng từ 5 ảnh đề xuất, không phải bản sao từng pixel.
Không lưu âm thanh, không gửi hội thoại ra ngoài, không có analytics hoặc tracking.
