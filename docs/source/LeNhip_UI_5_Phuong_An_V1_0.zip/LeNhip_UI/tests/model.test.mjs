import test from 'node:test';
import assert from 'node:assert/strict';
import {THEMES,newProfile,sanitizeSettings,restoreState,addTimeBlock} from '../dist/model.js';
test('five themes and isolated profile preferences',()=>{
 assert.equal(THEMES.length,5);
 const a=newProfile('A','a'),b=newProfile('B','b');a.settings.widgets.pop();a.settings.theme='night';
 assert.equal(b.settings.widgets.length,3);assert.equal(b.settings.theme,'orbit');
});
test('restore corrupted or unknown version recovers safely',()=>{
 for(const raw of ['bad','null','{}','{"version":2}','{"version":1,"profiles":[]}']){
  const s=restoreState(raw);assert.equal(s.profiles.length,1);assert.equal(s.activeId,s.profiles[0].id);
 }
});
test('stored profiles survive reload independently',()=>{
 const a=newProfile('A','a'),b=newProfile('B','b');b.settings.theme='titanium';a.lampOn=false;
 const s=restoreState(JSON.stringify({version:1,activeId:'b',profiles:[a,b]}));
 assert.equal(s.activeId,'b');assert.equal(s.profiles[1].settings.theme,'titanium');assert.equal(s.profiles[0].lampOn,false);
});
test('reject malicious theme/color and invalid settings',()=>{
 const p=sanitizeSettings({theme:'bad',accent:'url(javascript:1)',fontSize:999,name:'x',widgets:['sleep','sleep','unknown']});
 assert.equal(p.theme,'orbit');assert.equal(p.accent,'');assert.equal(p.fontSize,100);assert.deepEqual(p.widgets,['sleep']);
});
test('only exact allowed settings are imported',()=>{
 const s=sanitizeSettings({theme:'flow',name:' Tiến ',fontSize:130,accent:'#123abc',events:[{title:'private'}],widgets:[]});
 assert.equal(s.name,'Tiến');assert.equal(s.fontSize,130);assert.equal(s.accent,'#123abc');assert.equal('events' in s,false);
});
test('calendar conflict and repeated confirm do not create duplicate',()=>{
 const p=newProfile('A','a');assert.throws(()=>addTimeBlock(p,'09:15','09:45','one'));
 const next=addTimeBlock(p,'10:00','10:15','two');assert.equal(next.events.length,1);assert.equal(p.events.length,0);
 assert.throws(()=>addTimeBlock(next,'10:00','10:15','two'));
 assert.equal(addTimeBlock(next,'10:15','10:30','three').events.length,2);
});
test('calendar times validated',()=>{
 const p=newProfile('A','a');
 for(const pair of [['10:00','10:00'],['11:00','10:00'],['24:00','25:00'],['10:99','11:00'],['xx','yy']]) assert.throws(()=>addTimeBlock(p,...pair,'test'));
});
