LeNhip · 5 phương án logo và 5 phương án icon ứng dụng

Mỗi cặp dùng màu và hình khối tương ứng với một trong năm phong cách LeNhip.
Tất cả logo giữ cách viết LeNhip và dấu chấm chữ i hình trái tim.

PA01 Quỹ đạo            · L01 Quỹ đạo            + I01 Tim quỹ đạo
PA02 Không gian đêm     · L02 Không gian đêm     + I02 Trăng ôm tim
PA03 Nhịp an            · L03 Nhịp an            + I03 Lá nâng tim
PA04 Dòng thời gian     · L04 Dòng thời gian     + I04 Ba mốc
PA05 Titanium           · L05 Titanium          + I05 Ba không gian

Đề xuất nhận diện chính: L01 + I01.
L02 và L05 dùng chữ sáng. Đặt trên nền tối như bảng thiết kế.

Logo/SVG: chữ đã chuyển thành đường vector, nền trong suốt.
Logo/PNG: nền trong suốt, chiều rộng 1.800 px.
Icon/SVG: khung vuông 256 × 256.
Icon/PNG: nền vuông, 1.024 × 1.024 px. Các góc bo trên bảng là phần trình bày.
Bang_thiet_ke: hai bảng SVG và PNG để so sánh. Icon có bản xem ở 24–48 px.
